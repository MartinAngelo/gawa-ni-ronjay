import React from 'react'
import Nav from "../components/Nav";
// import Chat from "../components/Chat";

export default function Message() {
    return (
        <div>
            <Nav />
            <h1>Message</h1>
            {/* <Chat /> */}
        </div>
    )
}
