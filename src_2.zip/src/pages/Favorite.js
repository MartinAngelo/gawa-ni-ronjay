import React from 'react'
import Nav from "../components/Nav";

export default function Favorite() {
    return (
        <div>
            <Nav />
            <h1>Notification</h1>
        </div>
    )
}
