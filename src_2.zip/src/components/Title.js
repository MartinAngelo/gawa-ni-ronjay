import React from 'react';

const Title = () => {
  return (
    <div className="title">
      <h2>Upload</h2>
    </div>
  )
}

export default Title;